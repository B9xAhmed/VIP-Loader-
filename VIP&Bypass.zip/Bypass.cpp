PATCH_LIB("libanogs.so", "0x5492D0", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x1D49F8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x1D4F20", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x1D6EA4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x1D78CC", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x1D7938", "00 00 80 D2 C0 03 5F D6");

